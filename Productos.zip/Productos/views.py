from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q, Count
from collections import Counter
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models.deletion import ProtectedError
from django.urls import reverse
from django.template.loader import render_to_string

from .models import Producto
from .forms import ProductoForm
from compras.models import DetalleCompra
from core.global_ordenamiento import apply_smart_sorting,sorting_context


def is_ajax(request):
    return request.headers.get("x-requested-with") == "XMLHttpRequest"



def lista_productos(request):
    productos = Producto.objects.all()

    linea = request.GET.get("linea")
    if linea:
        productos = productos.filter(linea=linea)

    q = request.GET.get("q")
    if q:
        productos = productos.filter(
            Q(nombre__icontains=q)
            | Q(codigo__icontains=q)
            | Q(marca__icontains=q)
            | Q(presentacion__icontains=q)
            | Q(estado__icontains=q)
        )

    orden = request.GET.get("orden")
    if orden == "nombre":
        productos = productos.order_by("nombre")
    elif orden == "nombre_desc":
        productos = productos.order_by("-nombre")
    elif orden == "codigo":
        productos = productos.order_by("codigo")
    elif orden == "marca":
        productos = productos.order_by("marca")
    elif orden == "presentacion":
        productos = productos.order_by("presentacion")
    else:
        productos = productos.order_by("nombre")
    
    qs=Producto.objects.all()
    
    qs,sort_key,direction=apply_smart_sorting(request,qs,default_sort="nombre",default_dir="asc",aliases={"codigo":"codigo","nombre":"nombre","linea":"linea","marca":"marca"})
    

    total_productos = productos.count()

    productos_por_linea = (
        Producto.objects.values("linea")
        .annotate(total=Count("codigo"))
        .order_by("linea")
    )

    return render(request, "productos/lista_productos.html", {
        "productos": productos,
        "total_productos": total_productos,
        "productos_por_linea": productos_por_linea,
        "linea_seleccionada": linea,
        "productos": qs,
        **sorting_context(sort_key,direction)
    })
    
    
    from django.http import JsonResponse
from django.shortcuts import get_object_or_404

def detalle_compra_json(request, id):

    compra = get_object_or_404(
        Compra.objects.prefetch_related("detalles__producto"),
        id=id
    )

    primer = compra.detalles.first()

    imagen = ""

    if primer:
        if primer.producto.imagen:
            imagen = primer.producto.imagen.url
        elif primer.producto.imagen_url:
            imagen = primer.producto.imagen_url

    data = {
        "id": compra.id,
        "proveedor": str(compra.proveedor),
        "fecha": compra.fecha.strftime("%d de %B de %Y") if compra.fecha else "",
        "usuario": str(compra.usuario),
        "estado": "Activa" if compra.activo else "Anulada",
        "total": f"${compra.total:,.2f}",
        "imagen": imagen,
        "detalles": []
    }

    for d in compra.detalles.all():

        img = ""

        if d.producto.imagen:
            img = d.producto.imagen.url
        elif d.producto.imagen_url:
            img = d.producto.imagen_url

        data["detalles"].append({
            "nombre": d.producto.nombre,
            "cantidad": d.cantidad,
            "precio_unitario": f"${d.precio_unitario:,.2f}",
            "subtotal": f"${d.subtotal:,.2f}",
            "imagen": img,
        })

    return JsonResponse(data)

def crear_producto(request):
    form = ProductoForm(request.POST or None, request.FILES or None)

    if request.method == "POST" and form.is_valid():
        producto = form.save()
        messages.success(request, f'Producto "{producto.nombre}" creado correctamente.')

        if is_ajax(request):
            return JsonResponse({"success": True})

        return redirect("productos:lista_productos")

    context = {
        "form": form,
        "action_url": reverse("productos:crear_producto"),
        "submit_label": "Crear",
        "title": "Crear producto",
    }

    if is_ajax(request):
        html = render_to_string("productos/formulario_producto.html", context, request=request)
        return JsonResponse({"success": False, "html": html, "title": context["title"]})

    return render(request, "productos/crear_producto.html", context)


def editar_producto(request, codigo):
    producto = get_object_or_404(Producto, codigo=codigo)
    form = ProductoForm(request.POST or None, request.FILES or None, instance=producto)
    
    imagen_inicial_url = ""
    if producto.imagen:
        try:
            imagen_inicial_url = producto.imagen.url
            
        except:
            imagen_inicial_url=""
            
    if not imagen_inicial_url and getattr(producto,"imagen_url",""):
        imagen_inicial_url=producto.imagen_url
    if request.method == "POST" and form.is_valid():
        producto = form.save()
        messages.success(request, f'Producto "{producto.nombre}" actualizado.')

        if is_ajax(request):
            return JsonResponse({"success": True})

        return redirect("productos:lista_productos")

    context = {
        "form": form,
        "action_url": reverse("productos:editar_producto", args=[codigo]),
        "submit_label": "Guardar cambios",
        "title": f"Editar producto: {producto.nombre}",
        "producto": producto,
        "imagen_inicial_url":imagen_inicial_url,
    }

    if is_ajax(request):
        html = render_to_string("productos/formulario_producto.html", context, request=request)
        return JsonResponse({"success": False, "html": html, "title": context["title"]})

    return render(request, "productos/editar_producto.html", context)

def eliminar_producto(request, codigo):
    producto = get_object_or_404(Producto, codigo=codigo)

    action = (request.POST.get("action") or "").lower().strip()
    force_deactivate = request.POST.get("force_deactivate") == "1"

    if action == "activate":
        producto.activo = True
        producto.save(update_fields=["activo"])
        return JsonResponse({"status": "activated"})

    if action == "deactivate" or force_deactivate:
        producto.activo = False
        producto.save(update_fields=["activo"])
        return JsonResponse({"status": "inactivated"})

    
    try:
        producto.delete()
        return JsonResponse({"status": "deleted"})
    except ProtectedError as e:
        labels = [obj._meta.verbose_name_plural for obj in e.protected_objects]
        counts = Counter(labels)
        detalles = [{"nombre": k, "cantidad": v} for k, v in counts.items()]

        return JsonResponse(
            {
                "status": "protected",
                "title": "No se puede eliminar",
                "message": "Este producto está relacionado con otros registros.",
                "detalles": detalles,
            },
            status=409
        )